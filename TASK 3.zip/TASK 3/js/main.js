$(document).ready(function(){
 $(‘.header’).height($(window).height());
})
.page-footer {
background-color: #222;
color: #ccc;
padding: 60px 0 30px;
}
.footer-copyright {
color: #666;
padding: 40px 0;
}
